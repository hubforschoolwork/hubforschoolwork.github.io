# Project1
# Felicia Jimenez
#
This is my first project using HTML.

#This website is designed as a convenient method for the end-user to book winery tours quickly and conveniently.
#
#Design is such that it contains very basic instructions making use of "quick and convenient" methodology.
#User simply fills out required information in the form, clicks on the "submit" button and winery tour booking is complete.
#
#Technologies used:
  #.html
  #.css
  #GitHub
  #GitHub Pages
  #Visual Studio Code
  #www.validator.w3.org
  #www.draw.io
  #Bootstrap
  #www.formspree.io
#
#Future Improvements
  #Drop-down menu options on Navbar
  #Catered lunch options
  #Map showing additional wineries in the area along with major landmarks of interest.
  

  
